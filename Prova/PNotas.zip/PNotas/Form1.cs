﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            string[,] alunos = new string[2, 10];
            string[,] alunos1 = new string[2, 10];
            int i, j;
            string[] gabarito = { "A", "B", "C", "D", "E", "A", "B", "C", "D", "E" };
           

            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 10; j++)
                {
                    alunos1[i,j] = Interaction.InputBox($"Digite a resposta da questão {j + 1} a para o aluno: {i + 1}");
                    if(alunos1[i, j] != "A" && alunos1[i, j] != "a" && alunos1[i, j] != "B" && alunos1[i, j] != "b" && alunos1[i, j] != "C" && alunos1[i, j] != "c" && alunos1[i, j] != "D" && alunos1[i, j] != "d"  && alunos1[i, j] != "E" && alunos1[i, j] != "e")
                    {
                        MessageBox.Show("Resposta inválida");
                        j--;

                    }else
                        alunos[i, j] = alunos1[i, j].ToUpper();
                }

            }

            lstbx1.Items.Clear();
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 10; j++)
                {
                    if(string.Compare(alunos[i, j], gabarito[j]) == 0)
                    {
                        lstbx1.Items.Add($"O aluno: {i+1} acertou a questão {j+1} era {gabarito[j]} escolheu {alunos[i,j]}");
                    }else
                        lstbx1.Items.Add($"O aluno: {i + 1} errou a questão {j + 1} era {gabarito[j]} escolheu {alunos[i, j]}");


                }

            }
        }
    }
}
